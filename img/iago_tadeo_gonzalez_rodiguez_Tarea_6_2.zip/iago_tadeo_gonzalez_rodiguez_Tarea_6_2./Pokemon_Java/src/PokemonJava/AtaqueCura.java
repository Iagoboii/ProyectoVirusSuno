package PokemonJava;

public interface AtaqueCura {
    void sistemaCura(Pokemon pokemonVicima);
}
