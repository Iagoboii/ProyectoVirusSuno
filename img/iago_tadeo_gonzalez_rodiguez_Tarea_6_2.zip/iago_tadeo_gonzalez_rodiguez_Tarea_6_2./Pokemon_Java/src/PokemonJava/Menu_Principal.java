package PokemonJava;

import javax.swing.*;
import java.awt.event.*;

import static PokemonJava.Entrenador.pokemonUserActual;
import static PokemonJava.JuegoMain.*;


public class Menu_Principal {
     JPanel panelMenu_Principal;
     JButton botonBusquedaPoke;
     JButton botonVerEquipo;
     JButton botonCurarPoke;
     JButton botonReinicioPoke;
     JButton botonGuardaPartida;
     JButton botonCargaPartida;
     JButton botonSalir;
     JPanel subPanelPrincipal;
     JButton botonCambioPoke;


    public Menu_Principal() {
        //Listeners
        botonBusquedaPoke.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                comprobadorPreBatalla();

            }
        });
        botonCurarPoke.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ventanaCura();
            }
        });
        botonGuardaPartida.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sistemaGuardado();
            }
        });
        botonCargaPartida.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sistemaCargado();
            }
        });
        botonVerEquipo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ventanaInfoPokemon();
            }
        });
        botonReinicioPoke.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ventanaPokeReset();
            }
        });

        botonSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                preguntaSalirGuardado();
            }
        });
        menuPrincipal.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                preguntaSalirGuardado();

            }
        });
        botonCambioPoke.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pokemonUserActual = ventanaPokeCambio();

            }
        });
    }
}


