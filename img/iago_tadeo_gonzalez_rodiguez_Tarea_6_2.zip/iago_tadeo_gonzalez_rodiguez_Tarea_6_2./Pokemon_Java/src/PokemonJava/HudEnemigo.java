package PokemonJava;

import javax.swing.*;

public class HudEnemigo {
    JPanel panelHudEnemigo;
    JLabel labelNombreEnemigo;
    JProgressBar progressVidaEnemigo;
    JLabel labelSeparadorEnemigo;
    JLabel labelVidaMaxEnemigo;
    JLabel labelNivelEnemigo;
    JLabel labelVidaActualEnemigo;




}
