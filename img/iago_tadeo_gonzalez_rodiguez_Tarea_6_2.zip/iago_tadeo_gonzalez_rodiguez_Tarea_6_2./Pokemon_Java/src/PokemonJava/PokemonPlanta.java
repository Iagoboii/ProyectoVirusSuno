package PokemonJava;

public class PokemonPlanta extends Pokemon implements AtaqueDanio {

	public String toString() {
        return "Soy un " + getClass();
	}

	public void sonido() {
        System.out.println(getNombre() + " *Grito plantado*");
	}

	/**
	 * 
	 * @param puntoSaludMax
	 * @param puntoSaludActual
	 * @param puntoAtaque
	 * @param nombre
	 */
	public PokemonPlanta(double puntoSaludMax, double puntoSaludActual, double puntoAtaque, int nivel, double xpActual, double xpMax, String nombre) {
        super(puntoSaludMax, puntoSaludActual, puntoAtaque, nivel, xpActual, xpMax, nombre);
        setTipoElemento(2);
	}
    @Override
	public double sistemaAtaque() {
		return Math.floor(Math.random() * getPuntoAtaque() + 5);
	}

}