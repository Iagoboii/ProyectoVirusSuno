package PokemonJava;


public class PokemonAgua extends Pokemon implements AtaqueDanio {


	public void sonido() {
        System.out.println(getNombre() + " *Grito mojado*");
	}
    @Override
	public String toString() {
    return "Soy un " + getClass();
	}

	/**
	 * 
	 * @param puntoSaludMax
	 * @param puntoSaludActual
	 * @param puntoAtaque
	 * @param nombre
	 */
	public PokemonAgua(double puntoSaludMax, double puntoSaludActual, double puntoAtaque, int nivel, double xpActual, double xpMax, String nombre) {
        super(puntoSaludMax, puntoSaludActual, puntoAtaque, nivel, xpActual, xpMax, nombre);
        setTipoElemento(0);
	}
    @Override
	public double sistemaAtaque() {

        return Math.floor(Math.random() * getPuntoAtaque() + 5);
	}


}