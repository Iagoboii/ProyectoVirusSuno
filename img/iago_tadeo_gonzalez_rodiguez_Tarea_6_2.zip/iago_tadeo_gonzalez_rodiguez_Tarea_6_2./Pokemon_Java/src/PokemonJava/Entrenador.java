package PokemonJava;

import javax.swing.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

import static PokemonJava.JuegoMain.*;
import static PokemonJava.Pokemon.listaPokemon;


public class Entrenador implements Serializable {

    public static ArrayList<Pokemon> listaPokemonUser = new ArrayList<>();
    static int pokebolas = 10;
    static Scanner type = new Scanner(System.in);
    static int pokemonUserActual = 0;
    static ArrayList<Utilizables> bolsaUser = new ArrayList<>();


    public static ArrayList<Pokemon> getListaPokemonUser() {
        return listaPokemonUser;
    }

    public static void setListaPokemonUser(ArrayList<Pokemon> listaPokemonUser) {
        Entrenador.listaPokemonUser = listaPokemonUser;
    }

    public static ArrayList<Utilizables> getBolsaUser() {
        return bolsaUser;
    }

    public static void setBolsaUser(ArrayList<Utilizables> bolsaUser) {
        Entrenador.bolsaUser = bolsaUser;
    }

    public static int getPokebolas() {
        return pokebolas;
    }

    public static void setPokebolas(int pokebolas) {
        Entrenador.pokebolas = pokebolas;
    }

    //metodo que te permite la sustitucion o liberacion del pokemon capturado.
    static void modEquipoPokemonUser(Pokemon pokemonCambio) {
        String[] deciciones = {"Liberar Pokemon", "Sustituir Pokemon"};
        int seleccion = JOptionPane.showOptionDialog(null, "No hay espacio en el equipo, ¿Que quieres realizar?.", "Sistema", JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE, null, deciciones, deciciones[0]);
        System.out.println("No hay espacio en el equipo, ¿Que quieres realizar?.");
        if (seleccion == 0) {
            JOptionPane.showMessageDialog(null, "Liberaste a " + pokemonCambio.getNombre() + ".");
            finCombateProceso = true;
            batallaEnd();
        } else if (seleccion == 1) {
            String[] arrayListaPoke = new String[listaPokemonUser.size()];

            for (int i = 0; i < listaPokemonUser.size(); i++) {
                arrayListaPoke[i] = listaPokemonUser.get(i).getNombre() + " | " + listaPokemonUser.get(i).getPuntoSaludActual() + " / " + listaPokemonUser.get(i).getPuntoSaludMax() + " PV.";
            }

            int numSeleccion = 0;

            String seleccionPoke = (String) JOptionPane.showInputDialog(null, "¿A cual Pokemon quieres cambiar?", "Sistema", JOptionPane.QUESTION_MESSAGE, null, arrayListaPoke, arrayListaPoke[0]);
            if (seleccionPoke != null) {

                int indiceSustituir = -1;
                for (int i = 0; i < arrayListaPoke.length; i++) {
                    if (arrayListaPoke[i].equals(seleccionPoke)) {
                        indiceSustituir = i;
                        break;
                    }
                }

                if (indiceSustituir != -1) {
                    String nombreSustituido = listaPokemonUser.get(indiceSustituir).getNombre();


                    if (pokemonCambio instanceof PokemonAgua) {
                        listaPokemon.add(new PokemonAgua(pokemonCambio.getPuntoSaludMax(), pokemonCambio.getPuntoSaludMax(), pokemonCambio.getPuntoAtaque(), pokemonCambio.getNivel(), pokemonCambio.getXpActual(), pokemonCambio.getXpMax(), pokemonCambio.getNombre()));
                    } else if (pokemonCambio instanceof PokemonFuego) {
                        listaPokemon.add(new PokemonFuego(pokemonCambio.getPuntoSaludMax(), pokemonCambio.getPuntoSaludMax(), pokemonCambio.getPuntoAtaque(), pokemonCambio.getNivel(), pokemonCambio.getXpActual(), pokemonCambio.getXpMax(), pokemonCambio.getNombre()));
                    } else if (pokemonCambio instanceof PokemonPlanta) {
                        listaPokemon.add(new PokemonPlanta(pokemonCambio.getPuntoSaludMax(), pokemonCambio.getPuntoSaludMax(), pokemonCambio.getPuntoAtaque(), pokemonCambio.getNivel(), pokemonCambio.getXpActual(), pokemonCambio.getXpMax(), pokemonCambio.getNombre()));
                    } else if (pokemonCambio instanceof PokemonHada pokemonHada) {
                        listaPokemon.add(new PokemonHada(pokemonHada.getPuntoSaludMax(), pokemonHada.getPuntoSaludMax(), pokemonHada.getPuntoAtaque(), pokemonHada.getPpPokemonHadaMax(), pokemonHada.getNivel(), pokemonHada.getXpActual(), pokemonHada.getXpMax(), pokemonHada.getNombre()));
                    }


                    listaPokemonUser.set(indiceSustituir, pokemonCambio);
                    JOptionPane.showMessageDialog(null, "Sustituiste a " + nombreSustituido + " por " + pokemonCambio.getNombre() + ".");
                    ventanaInfoPokemon();
                    finCombateProceso = true;
                    batallaEnd();
                }
            }
        }


    }

    //Metodo que te permite el cambio de pokemons
    static void cambioEquipoPokemonUser() {
        do {
            int indicePokeCambio = ventanaPokeCambio();

            if (indicePokeCambio == -1) {
                JOptionPane.showMessageDialog(null, "Tienes que elegir un pokemon.", "Sistema", JOptionPane.ERROR_MESSAGE);
                System.out.println("Tienes que elegir un pokemon.");
            } else {
                if (listaPokemonUser.get(indicePokeCambio).getPuntoSaludActual() <= 0) {
                    JOptionPane.showMessageDialog(null, "Ese Pokemon está debilitado, elige otro.", "Sistema", JOptionPane.ERROR_MESSAGE);
                    System.out.println("Ese Pokemon está debilitado, elige otro.");
                } else {
                    pokemonUserActual = indicePokeCambio;
                    ui_Combate();
                    return;
                }

            }
        } while (true);


    }

    //Metodo que te permite la captura de pokemons
    static boolean capturar(Pokemon pokemonCapturado) {
        double pokevidaActual = pokemonCapturado.getPuntoSaludActual();
        double pokevidaMax = pokemonCapturado.getPuntoSaludMax();

        double probabilidadPokemon = 1 - (pokevidaActual / pokevidaMax);
        double valorCapturaCompleta = Math.random();

        if (valorCapturaCompleta < probabilidadPokemon) {
            JOptionPane.showMessageDialog(null, "¡Capturaste a " + pokemonCapturado.getNombre() + "!", "Sistema", JOptionPane.INFORMATION_MESSAGE);
            System.out.println("¡Capturaste a " + pokemonCapturado.getNombre() + "!");
            Entrenador.setPokebolas(Entrenador.getPokebolas() - 1);
            if (listaPokemonUser.size() < 6) {
                JOptionPane.showMessageDialog(null, pokemonCapturado.getNombre() + " se añadió a tu equipo.", "Sistema", JOptionPane.INFORMATION_MESSAGE);
                System.out.println(pokemonCapturado.getNombre() + " se añadió a tu equipo.");
                if (pokemonCapturado instanceof PokemonAgua) {
                    listaPokemon.add(new PokemonAgua(pokemonCapturado.getPuntoSaludMax(), pokemonCapturado.getPuntoSaludMax(),
                            pokemonCapturado.getPuntoAtaque(), pokemonCapturado.getNivel(), pokemonCapturado.getXpActual(),
                            pokemonCapturado.getXpMax(), pokemonCapturado.getNombre()));
                } else if (pokemonCapturado instanceof PokemonFuego) {
                    listaPokemon.add(new PokemonFuego(pokemonCapturado.getPuntoSaludMax(), pokemonCapturado.getPuntoSaludMax(),
                            pokemonCapturado.getPuntoAtaque(), pokemonCapturado.getNivel(), pokemonCapturado.getXpActual(),
                            pokemonCapturado.getXpMax(), pokemonCapturado.getNombre()));
                } else if (pokemonCapturado instanceof PokemonPlanta) {
                    listaPokemon.add(new PokemonPlanta(pokemonCapturado.getPuntoSaludMax(),
                            pokemonCapturado.getPuntoSaludMax(), pokemonCapturado.getPuntoAtaque(), pokemonCapturado.getNivel(), pokemonCapturado.getXpActual(),
                            pokemonCapturado.getXpMax(), pokemonCapturado.getNombre()));
                }
                listaPokemonUser.add(pokemonCapturado);
                menuPrincipal.setVisible(true);
                hudJugador.setVisible(false);
                hudEnemigo.setVisible(false);
                hudLuchaJugador.setVisible(false);

            } else {
                modEquipoPokemonUser(pokemonCapturado);

            }
        } else {
            JOptionPane.showMessageDialog(null, "¡" + pokemonCapturado.getNombre() + " no fue capturado!", "Sistema", JOptionPane.ERROR_MESSAGE);
            System.out.println("¡" + pokemonCapturado.getNombre() + " no fue capturado!");
            Entrenador.setPokebolas(Entrenador.getPokebolas() - 1);
        }
        return false;
    }


}
