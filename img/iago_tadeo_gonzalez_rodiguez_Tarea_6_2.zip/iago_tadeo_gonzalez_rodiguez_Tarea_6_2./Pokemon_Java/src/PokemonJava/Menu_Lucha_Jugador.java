package PokemonJava;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static PokemonJava.Entrenador.*;
import static PokemonJava.JuegoMain.*;
import static PokemonJava.Pokemon.*;
import static PokemonJava.Utilizables.curar;

public class Menu_Lucha_Jugador {
    JPanel panelLuchaPrincipal;
    JPanel subpanelLucha;
    JButton botonLuchar;
    JButton botonPokemonCambio;
    JButton botonCapturar;
    JButton botonBolsa;
    JButton botonHuir;


    public Menu_Lucha_Jugador() {
        //Listeners

        botonCapturar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                capturar(listaPokemon.get(pokemonSalvajeActual));
            }
        });
        botonBolsa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        botonHuir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                huir();

            }
        });
        botonLuchar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                opcionAtaqueUser(listaPokemonUser.get(pokemonUserActual));
            }
        });
        botonPokemonCambio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int indicePokeCambio = ventanaPokeCambio();

                if (indicePokeCambio == -1) {
                    System.out.println("No se realizó ningún cambio.");
                    ui_Combate();
                }  else {
                    pokemonUserActual = indicePokeCambio;
                    listaPokemonUser.get(pokemonUserActual);
                    opcionAtaquePokemon();
                    ui_Combate();
                }

            }
        });
        botonBolsa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int indiceItemCambio = ventanaItemAction();

                if (indiceItemCambio == -1) {
                    System.out.println("No se realizó ningún cambio.");

                }  else {
                    int indicePokeCambio = ventanaPokeCambio();

                    if (indicePokeCambio == -1) {
                        System.out.println("No se realizó ningún cambio.");
                        ui_Combate();
                    }  else {
                        curar(indiceItemCambio, indicePokeCambio);
                        ui_Combate();
                    }

                }
            }
        });
    }
}
