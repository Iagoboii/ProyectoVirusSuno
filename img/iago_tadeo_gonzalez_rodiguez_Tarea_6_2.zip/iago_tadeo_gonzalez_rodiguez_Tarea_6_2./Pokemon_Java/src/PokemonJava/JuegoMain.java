package PokemonJava;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.time.LocalDate;

import java.util.Scanner;

import static PokemonJava.Entrenador.*;
import static PokemonJava.Pokemon.*;

public class JuegoMain {

    static int pokemonSalvajeActual;

    static boolean finCombateProceso;
    static Scanner type = new Scanner(System.in);
    static int nivelPokemonMax = 1;
    static double pokeDinero = 0.0;
    static boolean introTerminado = false;
    static int regeneracionPokemonSalvaje = 15;
    //Frames
    static JFrame menuPrincipal = new JFrame("Pokemon Java");
    static JFrame menuIntroduccion = new JFrame("Pokemon Java");
    static JFrame hudEnemigo = new JFrame("Pokemon Java");
    static JFrame hudJugador = new JFrame("Pokemon Java");
    static JFrame hudLuchaJugador = new JFrame("Pokemon Java");
    //Variables para el sistema de guardado
    static int partidasWin, partidaLose, partidaPlayed;
    static LocalDate partidaFecha;
    static String nombreGuardado;
    //Variables para el modo desafio (No incluido).
    static double multiDinero = 1.0;
    static int diffLevelPoke = 0;
    static boolean desafioActivado;
    static int desafioRondaMax;
    static String seleccion;


    //Introduccion//

    //Metodo que te otorga tus objetos y tus pokemons  (Se inicia si no existe datos guardados).
    static void introduccion() {
        nombreGuardado = JOptionPane.showInputDialog(null, "Nombre de la partida guardada:", "SISTEMA", JOptionPane.QUESTION_MESSAGE);
        if (nombreGuardado == null || nombreGuardado.isEmpty() || nombreGuardado.equals(" ")){
            JOptionPane.showMessageDialog(null, "Tienes que poner un nombre para continuar", "SISTEMA", JOptionPane.INFORMATION_MESSAGE);
            introduccionPokemonJava();
            return;
        }
        System.out.println("*Bienvenido al mundo Pokemon, antes de comenzar, selecciona tu Pokemon inicial* - Profesor Oak");

        //Pokémon iniciales.
        PokemonPlanta Snivy_Ini = new PokemonPlanta(55, 55, 4.5, 1, 0, 20, "Snivy");
        PokemonAgua Qwilfish_Ini = new PokemonAgua(65, 65, 5.0, 1, 0, 20, "Qwilfish");
        PokemonFuego Scorbunny_Ini = new PokemonFuego(50, 50, 5.5, 1, 0, 20, "Scorbunny");
        //MissingNo es un pokemon cuya funcion sirve para testeos.
        PokemonFuego MissingNo = new PokemonFuego(9999, 9999, 1, 1, 0, 1, "MissingNo");
        String[] listaInicial = {Snivy_Ini.getNombre(), Qwilfish_Ini.getNombre(), Scorbunny_Ini.getNombre(), "err_405"};
        String seleccion = (String) JOptionPane.showInputDialog(null, "*Bienvenido al mundo Pokemon, antes de comenzar, selecciona tu Pokemon inicial*",
                "Profesor Oak", JOptionPane.QUESTION_MESSAGE, null, listaInicial, listaInicial[0]);
        try {
            switch (seleccion) {

                case "Snivy":
                    System.out.println("Seleccionaste a Snivy");
                    listaPokemonUser.add(Snivy_Ini);
                    JOptionPane.showMessageDialog(null, "Se ha seleccionado " + seleccion,
                            "Profesor Oak", JOptionPane.INFORMATION_MESSAGE);

                    break;
                case "Qwilfish":
                    System.out.println("Seleccionaste a Qwilfish");
                    listaPokemonUser.add(Qwilfish_Ini);
                    JOptionPane.showMessageDialog(null, "Se ha seleccionado " + seleccion,
                            "Profesor Oak", JOptionPane.INFORMATION_MESSAGE);

                    break;
                case "Scorbunny":
                    System.out.println("Seleccionaste a Scorbunny");
                    listaPokemonUser.add(Scorbunny_Ini);
                    JOptionPane.showMessageDialog(null, "Se ha seleccionado " + seleccion,
                            "Profesor Oak", JOptionPane.INFORMATION_MESSAGE);

                    break;
                case "err_405":
                    listaPokemonUser.add(MissingNo);
                    JOptionPane.showMessageDialog(null, "########### " + seleccion,
                            "@@@@@@@@", JOptionPane.INFORMATION_MESSAGE);

                    break;

            }
            menuPrincipal.setVisible(true);
        } catch (NullPointerException e){
            introduccionPokemonJava();
            return;
        }




        //Se le otorga automaticamente los objetos.
        Utilizables Pocion = new Utilizables("Poción", 10, 20);
        Utilizables Superpocion = new Utilizables("Superpoción", 8, 60);
        Utilizables Hiperpocion = new Utilizables("Hiperpoción", 3, 120);

        Utilizables Revivir = new Utilizables("Revivir", 3, 0.5);
        Utilizables Revivirmaximo = new Utilizables("Revivir Maxímo", 3, 1.0);


        bolsaUser.add(Pocion);
        bolsaUser.add(Superpocion);
        bolsaUser.add(Hiperpocion);
        bolsaUser.add(Revivir);
        bolsaUser.add(Revivirmaximo);
    }
    //Metodo que muestra el título
    public static void introduccionPokemonJava() {

        JPanel panelIntro = new JPanel();

        ImageIcon logo = new ImageIcon("img/imagenLogo.png");
        Image logoEscalado = logo.getImage().getScaledInstance(500, 400, Image.SCALE_SMOOTH);
        JLabel imagen = new JLabel(new ImageIcon(logoEscalado));


        JButton botonInicio = new JButton("Nueva Partida");
        JButton botonCarga = new JButton("Cargar Partida");
        JButton botonSalida = new JButton("Salir");
        panelIntro.setLayout(new BoxLayout(panelIntro, BoxLayout.Y_AXIS));

        imagen.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonInicio.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonCarga.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonSalida.setAlignmentX(Component.CENTER_ALIGNMENT);


        panelIntro.add(imagen);
        panelIntro.add(Box.createVerticalStrut(20));
        panelIntro.add(botonInicio);
        panelIntro.add(Box.createVerticalStrut(10));
        panelIntro.add(botonCarga);
        panelIntro.add(Box.createVerticalStrut(40));
        panelIntro.add(botonSalida);
        panelIntro.add(Box.createVerticalStrut(20));


        menuIntroduccion.add(panelIntro);
        menuIntroduccion.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        menuIntroduccion.pack();
        menuIntroduccion.setLocationRelativeTo(null);
        menuIntroduccion.setVisible(true);


        botonInicio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                menuIntroduccion.dispose();
                introduccion();

            }
        });

        botonCarga.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                File pokeData = new File("save/pokeData.dat");
                File itemData = new File("save/objetData.dat");
                File otherData = new File("save/otherData.dat");
                //Se comprueba si estos archivos existes.
                if (!(pokeData.exists() && itemData.exists() && otherData.exists())) {
                    JOptionPane.showMessageDialog(null, "No se pudo recuperar los datos guardados",
                            "Error de datos guardados", JOptionPane.ERROR_MESSAGE);
                } else {
                    sistemaCargado();
                    introTerminado = true;
                    menuPrincipal.setVisible(true);
                    menuIntroduccion.setVisible(false);
                }
            }
        });

        botonSalida.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

    }

    //Metodo main//

    //El mismo metodo main
    static void main() {
        introduccionPokemonJava();
        menuPrincipal.setContentPane(new Menu_Principal().panelMenu_Principal);
        menuPrincipal.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        menuPrincipal.pack();
        menuPrincipal.setLocationRelativeTo(null);
        pokemonIniciarLista();

        rgPokemonNivelAutoequilibrio();
        cambio_Caracteristicas_Pokemon_Global();

    }
    //Metodo que te muestra las estadisticas de todos los Pokemon
    public static void ventanaInfoPokemon() {
        String[] columnas = {"Nombre", "Vida", "Ataque", "Nivel", "Experiencia"};

        Object[][] datos = new Object[listaPokemonUser.size()][5];

        for (int i = 0; i < listaPokemonUser.size(); i++) {
            Pokemon pokeCheck = listaPokemonUser.get(i);
            datos[i][0] = pokeCheck.getNombre();
            datos[i][1] = String.format("%.2f / %.2f", pokeCheck.getPuntoSaludActual(), pokeCheck.getPuntoSaludMax());
            datos[i][2] = pokeCheck.getPuntoAtaque();
            datos[i][3] = pokeCheck.getNivel();
            datos[i][4] = String.format("%.2f / %.2f", pokeCheck.getXpActual(), pokeCheck.getXpMax());
        }


        JTable tabla = new JTable(datos, columnas);
        tabla.setEnabled(false);
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setPreferredSize(new Dimension(500, 200));

        JOptionPane.showMessageDialog(null, scroll, "Estadísticas del Equipo", JOptionPane.PLAIN_MESSAGE);
    }
    //Metodo que realiza la cura de tus pokemons
    public static void ventanaCura() {
        for (int i = 0; i < listaPokemonUser.size(); i++) {

            double vidaCurada = listaPokemonUser.get(i).getPuntoSaludMax();
            listaPokemonUser.get(i).setPuntoSaludActual(vidaCurada);
            if (listaPokemonUser.get(i) instanceof PokemonHada){
                ((PokemonHada) listaPokemonUser.get(i)).setPpPokemonHada(((PokemonHada) listaPokemonUser.get(i)).getPpPokemonHadaMax());
            }
        }
        JOptionPane.showMessageDialog(null, "¡Todos tus Pokemons fueron curados!", "Sistema", JOptionPane.INFORMATION_MESSAGE);

    }
    //Metodo que reinicia listaPokemon
    public static void ventanaPokeReset() {
        JOptionPane.showMessageDialog(null, "¡Haz forzado a que los Pokemons salvajes regresén.!", "Sistema", JOptionPane.INFORMATION_MESSAGE);
        pokemonIniciarLista();
        regeneracionPokemonSalvaje = 16;
    }

    //Pre combate//

    //Metodo que comprueba si se cumple las suficientes condiciones para iniciar el combate
    public static void comprobadorPreBatalla() {
        int pokemonEquipoDebiliado = 0;
        for (int i = 0; i < listaPokemonUser.size(); i++) {

            if (listaPokemonUser.get(i).getPuntoSaludActual() <= 0) {
                ++pokemonEquipoDebiliado;
            }
        }
        if (pokemonEquipoDebiliado == listaPokemonUser.size()) {
            JOptionPane.showMessageDialog(null, "Todos tus Pokemon's están debilitado.", "Sistema", JOptionPane.ERROR_MESSAGE);
            return;

        }
        --regeneracionPokemonSalvaje;
        JOptionPane.showMessageDialog(null, "¡Ha aparecido un Pokemon Salvaje!", "Sistema", JOptionPane.INFORMATION_MESSAGE);
        pokemonSalvajeActual = rnPokemonListaTotal();
        ++partidaPlayed;
        sistema_Combate();
    }
    //Metodo que cambia las estadísticas de los Pokemon's del usuario respecto al nivel que tienen estos.
    public static void cambio_Caracteristicas_Pokemon_User(Pokemon pokemonLevelUp) {
        pokemonLevelUp.setNivel(pokemonLevelUp.getNivel() + 1);
        pokemonLevelUp.setPuntoAtaque(pokemonLevelUp.getATAQUEBASE() + Math.floor(1.2 * pokemonLevelUp.getNivel()));
        pokemonLevelUp.setXpMax(pokemonLevelUp.getXpMax() + Math.floor(Math.random() * 10));
        pokemonLevelUp.setPuntoSaludMax(pokemonLevelUp.getPuntoSaludMax() + Math.floor(1.5 * pokemonLevelUp.getNivel()));
        pokemonLevelUp.setPuntoSaludActual(pokemonLevelUp.getPuntoSaludMax());
        if (pokemonLevelUp instanceof PokemonHada) {
            ((PokemonHada) pokemonLevelUp).setPpPokemonHadaMax(((PokemonHada) pokemonLevelUp).getPpPokemonHadaMax() + (int) Math.floor(((PokemonHada) pokemonLevelUp).getPpPokemonHadaMax() + 0.01 * pokemonLevelUp.getNivel()));
        }


    }

    //Interfaz de combate//

    //Metodo que muestra el nombre de los Pokemon y su vida.
    public static void ui_Combate() {
        hudEnemigo.getContentPane().removeAll();
        hudJugador.getContentPane().removeAll();


        HudEnemigo enemigo = new HudEnemigo();
        hudEnemigo.setContentPane(enemigo.panelHudEnemigo);
        enemigo.labelNombreEnemigo.setText(listaPokemon.get(pokemonSalvajeActual).getNombre());
        enemigo.labelNivelEnemigo.setText("Nivel " + listaPokemon.get(pokemonSalvajeActual).getNivel());
        if (listaPokemon.get(pokemonSalvajeActual).getPuntoSaludActual() >= 0){
            enemigo.labelVidaActualEnemigo.setText(String.valueOf(listaPokemon.get(pokemonSalvajeActual).getPuntoSaludActual()));
        }else {
            enemigo.labelVidaActualEnemigo.setText("0.0");
        }

        enemigo.labelVidaMaxEnemigo.setText(String.valueOf(listaPokemon.get(pokemonSalvajeActual).getPuntoSaludMax()));
        enemigo.progressVidaEnemigo.setMinimum(0);
        enemigo.progressVidaEnemigo.setMaximum((int) listaPokemon.get(pokemonSalvajeActual).getPuntoSaludMax());
        enemigo.progressVidaEnemigo.setValue((int) listaPokemon.get(pokemonSalvajeActual).getPuntoSaludActual());

        HudJugador jugador = new HudJugador();
        hudJugador.setContentPane(jugador.panelHudJugador);
        jugador.labelNombreJugador.setText(listaPokemonUser.get(pokemonUserActual).getNombre());
        jugador.labelNivelJugador.setText("Nivel " + listaPokemonUser.get(pokemonUserActual).getNivel());
        if (listaPokemonUser.get(pokemonUserActual).getPuntoSaludActual() >= 0){
            jugador.labelVidaActualJugador.setText(String.valueOf(listaPokemonUser.get(pokemonUserActual).getPuntoSaludActual()));
        }else {
            jugador.labelVidaActualJugador.setText("0.0");
        }

        jugador.labelVidaMaxJugador.setText(String.valueOf(listaPokemonUser.get(pokemonUserActual).getPuntoSaludMax()));
        jugador.progressVidaJugador.setMinimum(0);
        jugador.progressVidaJugador.setMaximum((int) listaPokemonUser.get(pokemonUserActual).getPuntoSaludMax());
        jugador.progressVidaJugador.setValue((int) listaPokemonUser.get(pokemonUserActual).getPuntoSaludActual());

        if (listaPokemonUser.get(pokemonUserActual) instanceof PokemonHada) {
            jugador.labelPpActual.setVisible(true);
            jugador.labelSeparadorPpJugador.setVisible(true);
            jugador.labelPpMax.setVisible(true);
            jugador.progressPpJugador.setVisible(true);
            jugador.progressPpJugador.setMinimum(0);
            jugador.progressPpJugador.setMaximum(((PokemonHada) listaPokemonUser.get(pokemonUserActual)).getPpPokemonHadaMax());
            jugador.progressPpJugador.setValue(((PokemonHada) listaPokemonUser.get(pokemonUserActual)).getPpPokemonHada());

            jugador.labelPpActual.setText(String.valueOf(((PokemonHada) listaPokemonUser.get(pokemonUserActual)).getPpPokemonHada()));
            jugador.labelPpMax.setText(String.valueOf(((PokemonHada) listaPokemonUser.get(pokemonUserActual)).getPpPokemonHadaMax()));
        } else {
            jugador.labelPpActual.setVisible(false);
            jugador.labelSeparadorPpJugador.setVisible(false);
            jugador.labelPpMax.setVisible(false);
            jugador.progressPpJugador.setVisible(false);
        }

        jugador.progressXPJugador.setMinimum(0);
        jugador.progressXPJugador.setMaximum((int) listaPokemonUser.get(pokemonUserActual).getXpMax());
        jugador.progressXPJugador.setValue((int) listaPokemonUser.get(pokemonUserActual).getXpActual());

        hudEnemigo.setSize(250, 250);
        hudJugador.setSize(250, 250);

        hudEnemigo.setLocation(1000, 100);
        hudJugador.setLocation(400, 400);

        hudEnemigo.repaint();
        hudJugador.repaint();

        hudEnemigo.setVisible(true);
        hudJugador.setVisible(true);
    }
    //Metodo que muestra las diferentes acciones que puede tomar el usuario.
    public static void ui_Jugador() {
        hudLuchaJugador.setContentPane(new Menu_Lucha_Jugador().panelLuchaPrincipal);
        hudLuchaJugador.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        hudLuchaJugador.pack();
        hudLuchaJugador.setLocationRelativeTo(null);
        hudLuchaJugador.setVisible(true);
    }
    //Metodo que realiza en hudJugador una animacion.
    public static void animacionUser() {
        int y = hudJugador.getY();
        for (int i = 0; i < 30; i++) {
            hudJugador.setLocation(400, (y - i));
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        for (int i = 0; i < 20; i++) {
            hudJugador.setLocation(400, (y + i));
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);

            }

        }
        hudJugador.setLocation(400, 400);
    }
    //Metodo que realiza en hudEnemigo una animacion.
    public static void animacionPokemon() {
        int y = hudEnemigo.getY();
        for (int i = 0; i < 30; i++) {
            hudEnemigo.setLocation(1000, (y - i));
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        for (int i = 0; i < 20; i++) {
            hudEnemigo.setLocation(1000, (y + i));
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        hudEnemigo.setLocation(1000, 100);
    }

    //Sistema Combate//

    //Metodo que inicia el combate.
    public static void sistema_Combate() {
        finCombateProceso = false;
        menuPrincipal.setVisible(false);
        ui_Jugador();
        hudLuchaJugador.setVisible(true);
        ui_Combate();
        hudEnemigo.setVisible(true);
        hudJugador.setVisible(true);

        System.out.print("\nTienes " + getPokebolas() + " pokebolas restantes.");


    }
    //Metodo que permite el usuario que realice una accion de tipo ataque
    public static void opcionAtaqueUser(Pokemon pokemonAtacante) {
        String[] ataqueNulo = {"Atacar"};
        String[] ataqueHada = {"Atacar", "Luz Lunar"};
        try {

            if (pokemonAtacante instanceof PokemonHada) {
                seleccion = (String) JOptionPane.showInputDialog(null, "*¿Que accion quieres realizar?*",
                        "Sistema", JOptionPane.QUESTION_MESSAGE, null, ataqueHada, ataqueHada[0]);

            } else {
                seleccion = (String) JOptionPane.showInputDialog(null, "*¿Que accion quieres realizar?*",
                        "Sistema", JOptionPane.PLAIN_MESSAGE, null, ataqueNulo, ataqueNulo[0]);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "xd");
        }
        try {
            switch (seleccion) {
                case "Atacar":
                    animacionUser();
                    atacar(listaPokemonUser.get(pokemonUserActual), listaPokemon.get(pokemonSalvajeActual));
                    ui_Combate();
                    if (batallaEnd()) {
                        return;
                    }
                    opcionAtaquePokemon();


                    break;
                case "Luz Lunar":
                    ((PokemonHada) listaPokemonUser.get(pokemonUserActual)).sistemaCura(listaPokemonUser.get(pokemonUserActual));
                    ui_Combate();
                    if (batallaEnd()) {
                        return;
                    }
                    opcionAtaquePokemon();

                    break;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Haz cancelado la acción");
        }
    }
    //Metodo que permite el pokemon salvaje realice una accion de tipo ataque
    public static void opcionAtaquePokemon() {
        if (listaPokemon.get(pokemonSalvajeActual) instanceof PokemonHada && rgPokemonHabilidadActivado(listaPokemon.get(pokemonSalvajeActual))) {
            iaHabilidadTipo(listaPokemon.get(pokemonSalvajeActual));
        } else {
            animacionPokemon();
            atacar(listaPokemon.get(pokemonSalvajeActual), listaPokemonUser.get(pokemonUserActual));
        }
        ui_Combate();
        batallaEnd();
    }
    //Metodo que realiza el proceso de ataque.
    public static void atacar(Pokemon pokemonAtacante, Pokemon pokemonDefensor) {
        double danioInfligido = 0;
        String reaccion = "";
        JOptionPane.showMessageDialog(null, "¡" + pokemonAtacante.getNombre() + " ataca!", "Sistema", JOptionPane.INFORMATION_MESSAGE);
        System.out.println("¡" + pokemonAtacante.getNombre() + " ataca!");
        switch (pokemonAtacante.getTipoElemento()) {
            case 0: // Tipo agua
                if (pokemonDefensor.getTipoElemento() == 0) {
                    danioInfligido = pokemonAtacante.sistemaAtaque();
                    reaccion = "";
                } else if (pokemonDefensor.getTipoElemento() == 1) {
                    danioInfligido = (pokemonAtacante.sistemaAtaque() * 2);
                    reaccion = "¡Es superefectivo!";
                } else if (pokemonDefensor.getTipoElemento() == 2) {
                    danioInfligido = pokemonAtacante.sistemaAtaque() * 0.5;
                    reaccion = "Es poco efectivo...";
                } else if (pokemonDefensor.getTipoElemento() == 3) {
                    danioInfligido = pokemonAtacante.sistemaAtaque();
                    reaccion = "";
                }
                pokemonDefensor.setPuntoSaludActual(pokemonDefensor.getPuntoSaludActual() - danioInfligido);
                break;
            case 1: // Tipo fuego
                if (pokemonDefensor.getTipoElemento() == 0) {
                    danioInfligido = pokemonAtacante.sistemaAtaque() * 0.5;
                    reaccion = "Es poco efectivo...";
                } else if (pokemonDefensor.getTipoElemento() == 1) {
                    danioInfligido = pokemonAtacante.sistemaAtaque();
                    reaccion = "";
                } else if (pokemonDefensor.getTipoElemento() == 2) {
                    danioInfligido = pokemonAtacante.sistemaAtaque() * 2;
                    reaccion = "¡Es superefectivo!";
                } else if (pokemonDefensor.getTipoElemento() == 3) {
                    danioInfligido = pokemonAtacante.sistemaAtaque();
                    reaccion = "";
                }
                pokemonDefensor.setPuntoSaludActual(pokemonDefensor.getPuntoSaludActual() - danioInfligido);
                break;
            case 2: // Tipo planta
                if (pokemonDefensor.getTipoElemento() == 0) {
                    danioInfligido = pokemonAtacante.sistemaAtaque() * 2;
                    reaccion = "¡Es superefectivo!";
                } else if (pokemonDefensor.getTipoElemento() == 1) {
                    danioInfligido = pokemonAtacante.sistemaAtaque() * 0.5;
                    reaccion = "Es poco efectivo...";
                } else if (pokemonDefensor.getTipoElemento() == 2) {
                    danioInfligido = pokemonAtacante.sistemaAtaque();
                    reaccion = "";
                } else if (pokemonDefensor.getTipoElemento() == 3) {
                    danioInfligido = pokemonAtacante.sistemaAtaque();
                    reaccion = "";
                }
                pokemonDefensor.setPuntoSaludActual(pokemonDefensor.getPuntoSaludActual() - danioInfligido);
                break;
            case 3: // Tipo hada
                if (pokemonDefensor.getTipoElemento() == 0) {
                    danioInfligido = pokemonAtacante.sistemaAtaque();
                    reaccion = "";
                } else if (pokemonDefensor.getTipoElemento() == 1) {
                    danioInfligido = pokemonAtacante.sistemaAtaque() * 0.5;
                    reaccion = "Es poco efectivo...";
                } else if (pokemonDefensor.getTipoElemento() == 2) {
                    danioInfligido = pokemonAtacante.sistemaAtaque();
                    reaccion = "";
                } else if (pokemonDefensor.getTipoElemento() == 3) {
                    danioInfligido = pokemonAtacante.sistemaAtaque();
                    reaccion = "";
                }
                pokemonDefensor.setPuntoSaludActual(pokemonDefensor.getPuntoSaludActual() - danioInfligido);
                break;


        }
        JOptionPane.showMessageDialog(null, "¡" + pokemonAtacante.getNombre() + " ha infligido " + danioInfligido + " puntos de daño!" + "\n" + reaccion, "Sistema", JOptionPane.INFORMATION_MESSAGE);

        System.out.println("¡" + pokemonAtacante.getNombre() + " ha infligido " + danioInfligido + " puntos de daño!");
        System.out.println(reaccion);
    }
    //Metodo que te permite salir de un combate
    static void huir() {
        JOptionPane.showMessageDialog(null, "Haz huído del combate", "Sistema", JOptionPane.INFORMATION_MESSAGE);
        System.out.println("Haz huído del combate");
        menuPrincipal.setVisible(true);
        hudJugador.setVisible(false);
        hudEnemigo.setVisible(false);
        hudLuchaJugador.setVisible(false);

    }



    //Fin de Partida//

    //Metodo que muestra menuPrincipal si se acaba el combate
    public static boolean batallaEnd() {

        if (finCombateProceso) {
            xpUserGanado();
            menuPrincipal.setVisible(true);
            hudJugador.setVisible(false);
            hudEnemigo.setVisible(false);
            hudLuchaJugador.setVisible(false);
            return true;
        }
        finCombateProceso = deteccionDebilitamiento();
        if (finCombateProceso) {
            menuPrincipal.setVisible(true);
            hudJugador.setVisible(false);
            hudEnemigo.setVisible(false);
            hudLuchaJugador.setVisible(false);
            return true;
        }
        return false;
    }
    //Metodo que detecta y acaba la partida si algún Pokemon es debilitado
    static boolean deteccionDebilitamiento() {
        if (listaPokemonUser.contains(listaPokemon.get(pokemonSalvajeActual))) {
            JOptionPane.showMessageDialog(null, "¡Haz ganado!", "Sistema", JOptionPane.INFORMATION_MESSAGE);
            System.out.println("¡Haz ganado!");
            pokeDinero = pokeDinero + generacionDinero();
            listaPokemon.remove(listaPokemon.get(pokemonSalvajeActual));
            partidasWin++;
            xpUserGanado();
            return true;
        }
        if (listaPokemon.get(pokemonSalvajeActual).getPuntoSaludActual() <= 0) {
            JOptionPane.showMessageDialog(null, "¡" + listaPokemon.get(pokemonSalvajeActual).getNombre() + " ha sido debilitado!", "Sistema", JOptionPane.INFORMATION_MESSAGE);
            System.out.println("¡" + listaPokemon.get(pokemonSalvajeActual).getNombre() + " ha sido debilitado!");
            JOptionPane.showMessageDialog(null, "¡Haz ganado!", "Sistema", JOptionPane.INFORMATION_MESSAGE);
            System.out.println("¡Haz ganado!");
            pokeDinero = pokeDinero + generacionDinero();
            listaPokemon.remove(listaPokemon.get(pokemonSalvajeActual));
            partidasWin++;
            xpUserGanado();

            return true;
        } else if (listaPokemonUser.get(pokemonUserActual).getPuntoSaludActual() <= 0) {
            JOptionPane.showMessageDialog(null, "¡" + listaPokemonUser.get(pokemonUserActual).getNombre() + " ha sido debilitado!", "Sistema", JOptionPane.INFORMATION_MESSAGE);
            System.out.println("¡" + listaPokemonUser.get(pokemonUserActual).getNombre() + " ha sido debilitado!");
            boolean finPartidaUser = false;
            int pokemonUserDebilitado = 0;
            for (Pokemon pokemon : listaPokemonUser) {
                if (pokemon.getPuntoSaludActual() <= 0) {
                    pokemonUserDebilitado++;
                }
            }
            if (pokemonUserDebilitado == listaPokemonUser.size()) {
                finPartidaUser = true;
            }
            if (finPartidaUser) {
                JOptionPane.showMessageDialog(null, "Tienes todos tus Pokemon's debilitado.", "Sistema", JOptionPane.INFORMATION_MESSAGE);
                JOptionPane.showMessageDialog(null, "Haz perdido...", "Sistema", JOptionPane.ERROR_MESSAGE);
                System.out.println("Tienes todos tus Pokemon's debilitado.");
                System.out.println("Haz perdido...");
                partidaLose++;
                return true;
            }

            cambioEquipoPokemonUser();
            return false;
        }
        return false;
    }
    //Metodo que genera una cantidad de xp tras una victoria
    static void xpUserGanado() {
        int calculoA;
        double multiplicadorXp;
        double xpOptenido;
        for (int i = 0; i < listaPokemonUser.size(); i++) {
            calculoA = (int) (Math.random() * 3);
            multiplicadorXp = 1.0 + (calculoA * 1.5);
            xpOptenido = listaPokemonUser.get(i).getXpActual() + (2 * multiplicadorXp);
            JOptionPane.showMessageDialog(null, "¡" + listaPokemonUser.get(i).getNombre() + " a obtenido " + 2 * multiplicadorXp + " puntos de experiencia!", "SISTEMA", JOptionPane.INFORMATION_MESSAGE);
            System.out.println("¡" + listaPokemonUser.get(i).getNombre() + " a obtenido " + 2 * multiplicadorXp + " puntos de experiencia!");
            listaPokemonUser.get(i).setXpActual(xpOptenido);
            if (listaPokemonUser.get(i).getXpActual() >= listaPokemonUser.get(i).getXpMax()) {
                do {
                    double diferencialXp = listaPokemonUser.get(i).getXpActual() - listaPokemonUser.get(i).getXpMax();
                    JOptionPane.showMessageDialog(null, "¡" + listaPokemonUser.get(i).getNombre() + " ha subido de nivel!", "SISTEMA", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("¡" + listaPokemonUser.get(i).getNombre() + " ha subido de nivel!");
                    listaPokemonUser.get(i).setXpActual(diferencialXp);
                    cambio_Caracteristicas_Pokemon_User(listaPokemonUser.get(i));
                    rgPokemonNivelAutoequilibrio();
                    cambio_Caracteristicas_Pokemon_Global();
                } while (listaPokemonUser.get(i).getXpActual() >= listaPokemonUser.get(i).getXpMax());


            }

        }

    }
    //Metodo que genera dinero tras una victoria
    static double generacionDinero() {
        double dineroGanado = 5 + ((Math.floor(Math.random() * 5) + 1) * (0.6 * listaPokemon.get(pokemonSalvajeActual).getNivel()));

        if (desafioActivado) {
            return dineroGanado * multiDinero;
        }
        JOptionPane.showMessageDialog(null, "¡Haz ganado " + dineroGanado + " pokedólares!", "SISTEMA", JOptionPane.INFORMATION_MESSAGE);

        return dineroGanado;
    }

    // Sistema de Uso y Cambio//

    //Metodo que permite el cambio de pokemons
    public static int ventanaPokeCambio() {
        String[] arrayListaPoke = new String[listaPokemonUser.size()];

        for (int i = 0; i < listaPokemonUser.size(); i++) {
            arrayListaPoke[i] = listaPokemonUser.get(i).getNombre() + " | " + listaPokemonUser.get(i).getPuntoSaludActual() + " / " + listaPokemonUser.get(i).getPuntoSaludMax() + " PV.";
        }

        int numSeleccion;

        seleccion = (String) JOptionPane.showInputDialog(null, "¿A cual Pokemon quieres cambiar?", "Sistema", JOptionPane.QUESTION_MESSAGE, null, arrayListaPoke, arrayListaPoke[0]);
        if (seleccion != null) {
            for (int i = 0; i < arrayListaPoke.length; i++) {
                if (arrayListaPoke[i].equals(seleccion)) {
                    numSeleccion = i;
                    return numSeleccion;
                }
            }
        }
        return -1;

    }
    //Metodo que permite el uso de pokemons
    public static int ventanaItemAction() {
        String[] arrayListaItems = new String[bolsaUser.size()];
        System.out.printf(String.valueOf(Entrenador.bolsaUser.size()));
        for (int i = 0; i < bolsaUser.size(); i++) {
            arrayListaItems[i] = bolsaUser.get(i).getNombre() + " | Cantidad: " + bolsaUser.get(i).getCantidad();

        }

        int numSeleccion;

        seleccion = (String) JOptionPane.showInputDialog(null, "¿Qué objeto quieres usar?", "Sistema", JOptionPane.QUESTION_MESSAGE, null, arrayListaItems, arrayListaItems[0]);

        if (seleccion != null) {
            for (int i = 0; i < arrayListaItems.length; i++) {
                if (arrayListaItems[i].equals(seleccion)) {
                    numSeleccion = i;
                    if (bolsaUser.get(numSeleccion).getCantidad() < 0){
                        JOptionPane.showMessageDialog(null, "Tienes 0 unidades de " + bolsaUser.get(numSeleccion).getNombre() + "." );
                        return -1;
                    }else {
                        return numSeleccion;
                    }

                }
            }
        }
        return -1;
    }

    //IA de Pokemon//

    //Metodo que genera un boolean aleatoriamente para que los Pokemons active su abilidad especial
    static boolean rgPokemonHabilidadActivado(Pokemon iaPokemon) {
        int valorGenerado = (int) Math.floor((Math.random() * 100) + 1);
        int valorPosible = 95;
        if (iaPokemon instanceof PokemonHada) {
            valorPosible = 95;
        }

        int modificador = 10 * (int) ((iaPokemon.getPuntoSaludActual()) / iaPokemon.getPuntoSaludMax());
        int valorGanador = valorPosible - modificador;
        return valorGenerado > valorGanador;
    }
    //Metodo que realiza la habilidad especial de los pokemon salvajes
    static void iaHabilidadTipo(Pokemon iaPokemon) {
        if (iaPokemon instanceof PokemonHada) {
            ((PokemonHada) iaPokemon).sistemaCura(iaPokemon);
        }
    }

    //Sistema de Guardado//

    //Metodo que permite guardar los datos de una partida.
    static void sistemaGuardado() {
        try (ObjectOutputStream oss = new ObjectOutputStream(new FileOutputStream("save/pokeData.dat"))) {
            for (int i = 0; i < listaPokemonUser.size(); i++) {
                oss.writeObject(listaPokemonUser.get(i));
            }

        } catch (IOException e) {
            System.out.println("Error al guardar la partida.");
        }
        try (ObjectOutputStream oss = new ObjectOutputStream(new FileOutputStream("save/objetData.dat"))) {
            for (int i = 0; i < bolsaUser.size(); i++) {
                oss.writeObject(bolsaUser.get(i));
            }


        } catch (IOException e) {
            System.out.println("Error al guardar la partida.");
        }
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream("save/otherData.dat"))) {
            dos.writeInt(pokebolas);
            dos.writeInt(partidaLose);
            dos.writeInt(partidasWin);
            dos.writeDouble(pokeDinero);
            dos.writeUTF(nombreGuardado);
        } catch (IOException e) {
            System.err.println("Error al guardar la partida.");
        }
        partidaPlayed = partidasWin + partidaLose;
        partidaFecha = LocalDate.now();
        System.out.printf("\nFecha de guardado: " + partidaFecha);
        String mensaje = String.format("""
        ######################################
         INFORMACIÓN DE LA PARTIDA GUARDADA
          - Nombre: %s
          - Partida Ganadas: %d
          - Partida Perdida: %d
          - Partidas Jugadas: %d
          - Dinero: %.2f
        ######################################
        """, nombreGuardado, partidasWin, partidaLose, partidaPlayed, pokeDinero);

        JOptionPane.showMessageDialog(null, mensaje, "Estadísticas de Entrenador", JOptionPane.INFORMATION_MESSAGE
        );
    }
    //Metodo que permite cargar los datos de una partida anterior.
    static void sistemaCargado() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("save/pokeData.dat"))) {
            try {
                while (true) {

                    Pokemon pokemon = (Pokemon) ois.readObject();
                    if (pokemon != null) {
                        listaPokemonUser.add(pokemon);
                    }

                }
            } catch (EOFException e) {
                System.out.println("Lectura pokedata.dat completada.");
                JOptionPane.showMessageDialog(null, "Lectura pokedata.dat completada.",
                        "Sistema", JOptionPane.INFORMATION_MESSAGE);

            }

        } catch (IOException e) {
            System.err.println("Error al Cargar la partida la partida.");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("save/objetData.dat"))) {
            try {


            while (true) {
                Utilizables utilizables = (Utilizables) ois.readObject();
                if (utilizables != null) {
                    bolsaUser.add(utilizables);
                }
            }
        }catch (EOFException e) {
                JOptionPane.showMessageDialog(null, "Lectura objetData.dat completada",
                        "Sistema", JOptionPane.INFORMATION_MESSAGE);
                System.out.println("Lectura objetData.dat completada.");
            }

        }  catch (IOException e) {
            System.err.println("Error al Cargar la partida la partida.");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        try (DataInputStream dis = new DataInputStream(new FileInputStream("save/otherData.dat"))) {
            try {
                setPokebolas(dis.readInt());
                partidaLose = dis.readInt();
                partidasWin = dis.readInt();
                pokeDinero = dis.readDouble();
                partidaPlayed = partidaLose + partidasWin;
                nombreGuardado = dis.readUTF();
            } catch (EOFException e) {
                JOptionPane.showMessageDialog(null, "Lectura otherData.dat completada.",
                        "Sistema", JOptionPane.INFORMATION_MESSAGE);
                System.out.println("Lectura otherData.dat completada.");
            }


        } catch (IOException e) {
            System.err.println("Error al Cargar la partida la partida.");
        }
    }
    //Metodo que te pregunta si quieres guardar antes de cerrar el programa
    public static void preguntaSalirGuardado() {
        int respuesta = JOptionPane.showConfirmDialog(null, "¿Quieres guardar la partida antes de salir?");

        if (respuesta == JOptionPane.YES_OPTION) {
            sistemaGuardado();
            System.exit(0);
        } else if (respuesta == JOptionPane.NO_OPTION) {
            System.exit(0);
        }

    }


}
