package PokemonJava;

import java.io.*;
import java.util.ArrayList;

import static PokemonJava.Entrenador.listaPokemonUser;
import static PokemonJava.JuegoMain.nivelPokemonMax;


public abstract class Pokemon implements AtaqueDanio, Serializable {

	private double puntoSaludMax;
	private double puntoSaludActual;
	private double puntoAtaque;
	private String nombre;
    private int nivel;
    private double xpMax;
    private double xpActual;
    private final double ATAQUEBASE = 5 * puntoAtaque;
    static ArrayList<Pokemon> listaPokemon = new ArrayList<>(); // Inicializa la lista para los PokemonJava salvajes.

    private int tipoElemento;
    // El atributo estático tipoElemento da un valor numerico respecto al tipo del pokemon.
    // 0 = Tipo agua
    // 1 = Tipo fuego
    // 2 = Tipo planta
    // 3 = Tipo hada

    // Getters y Setters
    public double getATAQUEBASE() {
        return ATAQUEBASE;
    }

    public int getTipoElemento() {
        return tipoElemento;
    }

    public void setTipoElemento(int tipoElemento) {
        this.tipoElemento = tipoElemento;
    }

    public double getXpActual() {
        return xpActual;
    }

    public void setXpActual(double xpActual) {
        this.xpActual = xpActual;
    }

    public double getXpMax() {
        return xpMax;
    }

    public void setXpMax(double xpMax) {
        this.xpMax = xpMax;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPuntoAtaque() {
        return puntoAtaque;
    }

    public void setPuntoAtaque(double puntoAtaque) {
        this.puntoAtaque = puntoAtaque;
    }

    public double getPuntoSaludActual() {
        return puntoSaludActual;
    }

    public void setPuntoSaludActual(double puntoSaludActual) {
        this.puntoSaludActual = puntoSaludActual;
    }

    public double getPuntoSaludMax() {
        return puntoSaludMax;
    }

    public void setPuntoSaludMax(double puntoSaludMax) {
        this.puntoSaludMax = puntoSaludMax;
    }
    //Constructor
    public Pokemon(double puntoSaludMax, double puntoSaludActual, double puntoAtaque, int nivel, double xpActual, double xpMax, String nombre) {
        this.puntoSaludMax = puntoSaludMax;
        this.puntoSaludActual = puntoSaludActual;
        this.puntoAtaque = puntoAtaque;
        this.nombre = nombre;
        this.nivel = nivel;
        this.xpMax = xpMax;
        this.xpActual = xpActual;


    }

    //Metodo que genera un número cuyo valor maximo es la cantidad total de los Pokemon's
    public static int rnPokemonListaTotal() {
        return (int) Math.floor(Math.random() * listaPokemon.size());
    }
    //Metodo que te permite reiniciar el array list listaPokemon
    public static void pokemonIniciarLista() {


        //salvajes
        PokemonPlanta Snivy = new PokemonPlanta(45, 45, 4.5, 1, 0, 20, "Snivy");
        PokemonPlanta Bulbasaur = new PokemonPlanta(45, 45, 4.9, 1, 0, 20, "Bulbasaur");
        PokemonPlanta Chikorita = new PokemonPlanta(45, 45, 4.9, 1, 0, 20, "Chikorita");
        PokemonPlanta Treecko = new PokemonPlanta(40, 40, 4.5, 1, 0, 20, "Treecko");
        PokemonPlanta Turtwig = new PokemonPlanta(55, 55, 6.5, 1, 0, 20, "Turtwig");
        PokemonPlanta Pansage = new PokemonPlanta(50, 50, 5.3, 1, 0, 20, "Pansage");
        PokemonPlanta Chespin = new PokemonPlanta(56, 56, 6.1, 1, 0, 20, "Chespin");
        PokemonPlanta Rowlet = new PokemonPlanta(68, 68, 5.5, 1, 0, 20, "Rowlet");

        PokemonAgua Qwilfish = new PokemonAgua(65, 65, 5.5, 1, 0, 20, "Qwilfish");
        PokemonAgua Squirtle = new PokemonAgua(44, 44, 4.8, 1, 0, 20, "Squirtle");
        PokemonAgua Totodile = new PokemonAgua(50, 50, 6.5, 1, 0, 20, "Totodile");
        PokemonAgua Mudkip = new PokemonAgua(50, 50, 6.5, 1, 0, 20, "Mudkip");
        PokemonAgua Piplup = new PokemonAgua(53, 53, 5.1, 1, 0, 20, "Piplup");
        PokemonAgua Oshawott = new PokemonAgua(55, 55, 5.5, 1, 0, 20, "Oshawott");
        PokemonAgua Froakie = new PokemonAgua(41, 41, 5.6, 1, 0, 20, "Froakie");
        PokemonAgua Popplio = new PokemonAgua(50, 50, 5.4, 1, 0, 20, "Popplio");

        PokemonFuego Scorbunny = new PokemonFuego(50, 50, 6.1, 1, 0, 20, "Scorbunny");
        PokemonFuego Charmander = new PokemonFuego(39, 39, 5.2, 1, 0, 20, "Charmander");
        PokemonFuego Cyndaquil = new PokemonFuego(39, 39, 5.2, 1, 0, 20, "Cyndaquil");
        PokemonFuego Torchic = new PokemonFuego(45, 45, 6, 1, 0, 20, "Torchic");
        PokemonFuego Chimchar = new PokemonFuego(44, 44, 5.8, 1, 0, 20, "Chimchar");
        PokemonFuego Tepig = new PokemonFuego(65, 65, 6.3, 1, 0, 20, "Tepig");
        PokemonFuego Fennekin = new PokemonFuego(40, 40, 5.5, 1, 0, 20, "Fennekin");
        PokemonFuego Litten = new PokemonFuego(45, 45, 6.5, 1, 0, 20, "Litten");

        PokemonHada Clefairy = new PokemonHada(70,70, 4.5 , 12, 1, 0,15,"Clefairy");
        PokemonHada Togepi = new PokemonHada(35, 35, 8, 12, 1,0,15,"Togepi");
        PokemonHada Ralts = new PokemonHada(28, 28, 2.5, 12,1,0,15, "Ralts");
        PokemonHada Togekiss = new PokemonHada(85,85, 5, 10, 1, 0, 15, "Togekiss");
        PokemonHada Cottonee = new PokemonHada(40, 40, 2.7, 12,1, 0, 15, "Cottonee");
        PokemonHada Flabebe = new PokemonHada(44,44,3.8, 10,1,0,15,"Flabébé");
        PokemonHada Cutiefly = new PokemonHada(40,40,4.5,12, 1,0,15, "Cutiefly");
        PokemonHada Milcery = new PokemonHada(45,45,4, 12,1,0,15, "Milcery");

        PokemonPlanta Virizion = new PokemonPlanta(100,100,8, 1,0, 5, "Virizion");
        PokemonFuego Ho_oh = new PokemonFuego(90, 90, 12, 1, 0, 30, "Ho-Oh");
        PokemonAgua Kyogre = new PokemonAgua(250,250,5,1,0,30, "Kyogre");
        PokemonHada Xerneas = new PokemonHada(1000, 1000, 0.1, 15, 1, 0, 40, "Xerneas");

        listaPokemon.add(Clefairy);
        listaPokemon.add(Togepi);
        listaPokemon.add(Ralts);
        listaPokemon.add(Togekiss);
        listaPokemon.add(Cottonee);
        listaPokemon.add(Flabebe);
        listaPokemon.add(Cutiefly);
        listaPokemon.add(Milcery);
        listaPokemon.add(Bulbasaur);
        listaPokemon.add(Charmander);
        listaPokemon.add(Squirtle);
        listaPokemon.add(Snivy);
        listaPokemon.add(Qwilfish);
        listaPokemon.add(Scorbunny);
        listaPokemon.add(Chikorita);
        listaPokemon.add(Totodile);
        listaPokemon.add(Cyndaquil);
        listaPokemon.add(Treecko);
        listaPokemon.add(Mudkip);
        listaPokemon.add(Torchic);
        listaPokemon.add(Turtwig);
        listaPokemon.add(Piplup);
        listaPokemon.add(Chimchar);
        listaPokemon.add(Pansage);
        listaPokemon.add(Oshawott);
        listaPokemon.add(Tepig);
        listaPokemon.add(Chespin);
        listaPokemon.add(Froakie);
        listaPokemon.add(Fennekin);
        listaPokemon.add(Rowlet);
        listaPokemon.add(Popplio);
        listaPokemon.add(Litten);

        listaPokemon.add(Virizion);
        listaPokemon.add(Ho_oh);
        listaPokemon.add(Kyogre);
        listaPokemon.add(Xerneas);

    }

    //Metodo que cambia el nivel de los Pokemon's salvajes respecto al nivel maximo de un Pokemon del equipo del usuario.
    public static void rgPokemonNivelAutoequilibrio() {
        for (int i = 0; i < listaPokemonUser.size(); i++) {
            if (listaPokemonUser.get(i).getNivel() > nivelPokemonMax) {
                nivelPokemonMax = listaPokemonUser.get(i).getNivel();
            }
        }

        if (nivelPokemonMax > 1) {
            for (int j = 0; j < listaPokemon.size(); j++) {
                listaPokemon.get(j).setNivel((int) Math.floor(Math.random() * ((nivelPokemonMax + 3) - nivelPokemonMax) ) + nivelPokemonMax);
            }
        }
        if (nivelPokemonMax == 1) {
            for (int y = 0; y < listaPokemon.size(); y++) {
                listaPokemon.get(y).setNivel(1);
            }
        }
    }
    //Metodo que cambia las estadísticas de los Pokemon's salvajes respecto al nivel que tienen estos.
    public static void cambio_Caracteristicas_Pokemon_Global(){
        if (nivelPokemonMax != 1){
            for (int i = 0; i < listaPokemon.size(); i++) {
                listaPokemon.get(i).setPuntoAtaque(listaPokemon.get(i).getATAQUEBASE() + Math.floor(1.1 * listaPokemon.get(i).getNivel()));
                listaPokemon.get(i).setXpMax(listaPokemon.get(i).getXpMax() + Math.floor(Math.random() * 10));
                listaPokemon.get(i).setPuntoSaludMax(listaPokemon.get(i).getPuntoSaludMax() + Math.floor(1.5 * listaPokemon.get(i).getNivel()));
                listaPokemon.get(i).setPuntoSaludActual(listaPokemon.get(i).getPuntoSaludMax());
                if (listaPokemon.get(i) instanceof  PokemonHada){
                    ((PokemonHada) listaPokemon.get(i)).setPpPokemonHadaMax((int) (((PokemonHada) listaPokemon.get(i)).getPpPokemonHadaMax() + Math.floor(1.5 * listaPokemon.get(i).getNivel())));
                }

            }
        }
    }

    public String toString() {
		// TODO - implement PokemonJava.Pokemon.toString
		throw new UnsupportedOperationException();
	}

	public abstract void sonido();

}