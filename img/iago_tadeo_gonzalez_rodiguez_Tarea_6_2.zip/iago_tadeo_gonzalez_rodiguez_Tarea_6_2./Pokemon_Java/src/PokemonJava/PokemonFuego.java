package PokemonJava;

public class PokemonFuego extends Pokemon implements AtaqueDanio {

	public String toString() {
        return "Soy un " + getClass();
	}

	public void sonido() {
        System.out.println(getNombre() + " *Grito quemado*");
	}

	/**
	 * 
	 * @param puntoSaludMax
	 * @param puntoSaludActual
	 * @param puntoAtaque
	 * @param nombre
	 */
	public PokemonFuego(double puntoSaludMax, double puntoSaludActual, double puntoAtaque, int nivel, double xpActual, double xpMax, String nombre) {
        super(puntoSaludMax, puntoSaludActual, puntoAtaque, nivel, xpActual, xpMax, nombre);
        setTipoElemento(1);
	}
    @Override
	public double sistemaAtaque() {
        return Math.floor(Math.random() * getPuntoAtaque() + 5);
	}

}