package PokemonJava;

import javax.swing.*;

public class HudJugador {
    JPanel panelHudJugador;
    JProgressBar progressVidaJugador;
    JLabel labelNivelJugador;
    JLabel labelVidaActualJugador;
    JLabel labelSeparadorVidaJugador;
    JLabel labelVidaMaxJugador;
    JLabel labelNombreJugador;
    JLabel labelPpActual;
    JLabel labelSeparadorPpJugador;
    JLabel labelPpMax;
    JProgressBar progressPpJugador;
    JProgressBar progressXPJugador;
}
