package PokemonJava;

import javax.swing.*;
import java.io.Serializable;

import static PokemonJava.Entrenador.bolsaUser;
import static PokemonJava.Entrenador.listaPokemonUser;


public class Utilizables implements AtaqueCura, Serializable {
    //Atributos "comunes"
    private String nombre;
    private int cantidad;

    // Atributos para utilizables curativos.
    private int vidaACurar;
    private double porcentajeACurar;
    private int tipoCuracionId;
        //0 = Curacion fija
        //1 = Curacion mediante porcentaje
    //Atributos para utilizable recuperadora de PP

    //Atributos para eliminar efectos de estado


    ///                   ///
    /// OBJETOS CURATIVOS ///
    ///                   ///

    //Constructor para la poción curativa, curación fija.
    public Utilizables(String nombre, int cantidad, int vidaACurar){
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.vidaACurar = vidaACurar;
        tipoCuracionId = 0;
    }
    //Constructor para la poción curativa, curación mediante porcentaje. Puede revivir
    public Utilizables(String nombre, int cantidad, double porcentajeACurar){
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.porcentajeACurar = porcentajeACurar;
        tipoCuracionId = 1;

    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getVidaACurar() {
        return vidaACurar;
    }

    public void setVidaACurar(int vidaACurar) {
        this.vidaACurar = vidaACurar;
    }

    public double getPorcentajeACurar() {
        return porcentajeACurar;
    }

    public void setPorcentajeACurar(double porcentajeACurar) {
        this.porcentajeACurar = porcentajeACurar;
    }

    public int getTipoCuracionId() {
        return tipoCuracionId;
    }

    public void setTipoCuracionId(int tipoCuracionId) {
        this.tipoCuracionId = tipoCuracionId;
    }
    //Metodo que realiza la cura o revive a un pokemon
    @Override
    public void sistemaCura(Pokemon pokemonVicima) {
        if (tipoCuracionId == 0 && getCantidad() > 0){
            pokemonVicima.setPuntoSaludActual(pokemonVicima.getPuntoSaludActual() + vidaACurar);

        } else if (tipoCuracionId == 1 && getCantidad() > 0) {
            pokemonVicima.setPuntoSaludActual(pokemonVicima.getPuntoSaludMax() * porcentajeACurar);
        }
        if (pokemonVicima.getPuntoSaludActual() > pokemonVicima.getPuntoSaludMax()){
            pokemonVicima.setPuntoSaludActual(pokemonVicima.getPuntoSaludMax());
        }
    }
    //Metodo que realiza las comprobaciones y muestra el proceso para usar un utilizable
    public static void curar(int curaSelect, int pokeSelect ) {
        if (listaPokemonUser.get(pokeSelect).getPuntoSaludActual() > 0 && bolsaUser.get(curaSelect).getTipoCuracionId() == 0) {
            bolsaUser.get(curaSelect).sistemaCura(listaPokemonUser.get(pokeSelect));
            bolsaUser.get(curaSelect).setCantidad(bolsaUser.get(curaSelect).getCantidad() - 1);
            JOptionPane.showMessageDialog(null, listaPokemonUser.get(pokeSelect).getNombre() + " se ha curado " +
                    bolsaUser.get(curaSelect).getVidaACurar() + " PV.", "Sistema", JOptionPane.INFORMATION_MESSAGE);
            System.out.println(listaPokemonUser.get(pokeSelect).getNombre() + " se ha curado " + bolsaUser.get(curaSelect).getVidaACurar() + " PV.");
            if (bolsaUser.get(curaSelect).getCantidad() <= 0) {
                bolsaUser.get(curaSelect).setCantidad(0);
                return;
            }
            return;
        } else if (listaPokemonUser.get(pokeSelect).getPuntoSaludActual() <= 0 && bolsaUser.get(curaSelect).getTipoCuracionId() == 1) {
            bolsaUser.get(curaSelect).sistemaCura(listaPokemonUser.get(pokeSelect));
            bolsaUser.get(curaSelect).setCantidad(bolsaUser.get(curaSelect).getCantidad() - 1);
            JOptionPane.showMessageDialog(null, listaPokemonUser.get(pokeSelect).getNombre() + " ha sido revivido " +
                    bolsaUser.get(curaSelect).getPorcentajeACurar() + " % de PV del máximo.", "Sistema", JOptionPane.INFORMATION_MESSAGE);
            System.out.println(listaPokemonUser.get(pokeSelect).getNombre() + " ha sido revivido " +
                    bolsaUser.get(curaSelect).getPorcentajeACurar() + " % de PV del máximo.");
            if (bolsaUser.get(curaSelect).getCantidad() <= 0) {
                bolsaUser.get(curaSelect).setCantidad(0);
                return;
            }
            return;
        } else {
            if (bolsaUser.get(curaSelect).getTipoCuracionId() == 0) {
                JOptionPane.showMessageDialog(null, "Ese Pokemon está debilitado, no se puede curar.", "Sistema", JOptionPane.ERROR_MESSAGE);
                System.out.println("Ese Pokemon está debilitado, no se puede curar.");
            } else {
                JOptionPane.showMessageDialog(null, "No se puede usar el objeto en un Pokemon que no esté debilitado.", "Sistema", JOptionPane.ERROR_MESSAGE);
                System.out.printf("No se puede usar el objeto en un Pokemon que no esté debilitado.");
            }
        }
    }
}
