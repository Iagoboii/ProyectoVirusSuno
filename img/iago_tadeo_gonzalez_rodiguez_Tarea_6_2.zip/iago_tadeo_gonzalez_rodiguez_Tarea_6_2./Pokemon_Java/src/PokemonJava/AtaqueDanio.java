package PokemonJava;

public interface AtaqueDanio {

	double sistemaAtaque();

}