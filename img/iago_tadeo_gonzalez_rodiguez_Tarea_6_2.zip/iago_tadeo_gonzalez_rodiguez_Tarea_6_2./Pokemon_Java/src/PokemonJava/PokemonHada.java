package PokemonJava;

public class PokemonHada extends Pokemon implements AtaqueDanio, AtaqueCura {
private int ppPokemonHada;
private int ppPokemonHadaMax;

    public int getPpPokemonHadaMax() {
        return ppPokemonHadaMax;
    }

    public void setPpPokemonHadaMax(int ppPokemonHadaMax) {
        this.ppPokemonHadaMax = ppPokemonHadaMax;
    }

    public int getPpPokemonHada() {
        return ppPokemonHada;
    }

    public void setPpPokemonHada(int ppPokemonHada) {
        this.ppPokemonHada = ppPokemonHada;
    }

    public PokemonHada(double puntoSaludMax, double puntoSaludActual, double puntoAtaque, int ppPokemonHadaMax, int nivel, double xpActual, double xpMax, String nombre) {
        super(puntoSaludMax, puntoSaludActual, puntoAtaque, nivel, xpActual, xpMax, nombre);
        this.ppPokemonHadaMax = ppPokemonHadaMax;
        ppPokemonHada = ppPokemonHadaMax;
        setTipoElemento(3);
    }

    public void sonido() {
        System.out.println(getNombre() + " *Grito mágico*");
    }

    @Override
    public double sistemaAtaque() {

        return Math.floor(Math.random() * getPuntoAtaque() + 5);
    }

    //Metodo que realiza que el pokemo se cure a si mismo
    @Override
    public void sistemaCura(Pokemon pokemonVicima) {
        double potenciaCura = (double) pokemonVicima.getNivel() * 0.20;
        System.out.println(getNombre()+" usa Luz lunar");
        if (ppPokemonHada > 0){
            double curaVida = 10 + potenciaCura * ((Math.random() * (0.50 - 0.10) + 0.10) * getPuntoSaludMax());
            System.out.println(Math.round(potenciaCura) );
            System.out.println(Math.round(curaVida));
            pokemonVicima.setPuntoSaludActual(pokemonVicima.getPuntoSaludActual() + Math.round(curaVida));
            if (pokemonVicima.getPuntoSaludActual() > pokemonVicima.getPuntoSaludMax()){
                pokemonVicima.setPuntoSaludActual(pokemonVicima.getPuntoSaludMax());

                System.out.printf("\n" + getNombre() + " se ha curado al completo. (+ %d PV)\n", Math.round(curaVida));
                setPpPokemonHada(getPpPokemonHada()-1);
            }else {
                System.out.printf("\n" + getNombre() + " se ha curado %d PV\n", Math.round(curaVida));
                setPpPokemonHada(getPpPokemonHada()-1);
            }
        } else {
            System.out.println(getNombre() + " no se pudo curar porque no tiene suficiente PP.");
        }

    }
}
